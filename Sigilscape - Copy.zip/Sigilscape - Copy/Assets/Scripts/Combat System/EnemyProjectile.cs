﻿/*
    Nathan Cruz

    NOT COMPLETE BARELY EVEN STARTED
    THE IDEA IS FOR THIS TO HAVE SOME SORT OF PATTERN (MAY NEED SOMETHING LIKE AN AI, BUT REALLY IT'S JUST SOME PATTERN)
    THIS COLLIDES WITH THE PLAYER OBJECT (IGNORES ENEMIES) AND THE PLAYER.CS HANDLES THE REST

    Interface:
    damage - damage that is applied to player - Player.cs, Shield.cs
*/
using UnityEngine;
using System.Collections;

public class EnemyProjectile : MonoBehaviour {

    public int damage;
}
